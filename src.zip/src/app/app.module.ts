import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';
import { TestService } from './services/test.service';
import { ContactComponent } from './contact/contact.component';
import { RouterModule, Routes } from '@angular/router';
import { GalleryComponent } from './gallery/gallery.component';
import { GalleryService } from './services/gallery.service';
import { HttpModule } from '@angular/http';

const routes: Routes = [
  { path: "comments", component: TestComponent },
  { path: "contact", component: ContactComponent },
  { path: "gallery", component: GalleryComponent },  
  { path: "", redirectTo: "/contact", pathMatch: "full" }


];
@NgModule({
  declarations: [
    AppComponent,
    TestComponent,
    ContactComponent,
    GalleryComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpModule
  ],
  providers: [TestService, GalleryService],
  bootstrap: [AppComponent]
})
export class AppModule { }
